# CompProperties à vérifier
